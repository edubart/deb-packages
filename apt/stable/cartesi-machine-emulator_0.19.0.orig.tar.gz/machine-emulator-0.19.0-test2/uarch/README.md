# Cartesi Machine Microarchitecture Build Directory

This directory contains scripts and instructions to compile the Cartesi Machine emulator to microarchitecture code

