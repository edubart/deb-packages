# uarch

Build tests for the Cartesi Machine microarchitecture
